function gettime()
{
	var time=new Date(),year,month,day,hour,minute,second;
	var MSIE=navigator.userAgent.indexOf("MSIE");
	if(MSIE != -1)			year =(time.getYear());
	else			year = (time.getYear()+1900);
	month=time.getMonth()+1;		day=time.getDate();
	hour=time.getHours();		minute=time.getMinutes();
	second=time.getSeconds();
	if(month<10)	month='0'+month;
	if(day<10)		day='0'+day;
	if(hour<10)		hour='0'+hour;
	if(minute<10)	minute='0'+minute;
	if(second<10)	second='0'+second;
	var nowtime=year+month+day+hour+minute+second;
	return nowtime;
}

$(document).ready(function() {
	$('#sendbutton').click(function() {
		if ($('#name').val().length ==0) {
			$('#name').focus().css({
				//border: "1px solid red",
				boxShadow: "0 0 2px red"
			});
			alert("昵称不能为空哦");
			return false;
			}

		if ($('#name').val().length > 10) {
			$('#name').focus().css({
				//border: "1px solid red",
				boxShadow: "0 0 2px red"
			});
			alert("昵称长度不能多于10位哦");
			return false;
			}

		var sqq = /^[1-9]{1}[0-9]{4,9}$/;
		if (!sqq.test($('#qq').val()) || $('#qq').val().length < 5 || $('#qq').val().length > 12) {
			$('#qq').focus().css({
				//border: "1px solid red",
				boxShadow: "0 0 2px red"
			});
			alert("请正确填写你的QQ号哦");
			return false;
			}

		var message=$('#message').val();

		if ($('#message').val().length ==0) {
			$('#message').focus().css({
				//border: "1px solid red",
				boxShadow: "0 0 2px red"
			});
			alert("留言不能为空哦");
			return false;
			}
		if($('#message').val().length >200) {
			$('#message').focus().css({
				//border: "1px solid red",
				boxShadow: "0 0 2px red"
			});
			alert("留言内容过长，请缩短一点吧╯﹏╰");
			return false;
			}
		var power=$('#power option:selected').val();

		$.ajax({
			type:"POST",
			url: "./Messub.php",
			data:{name:$("#name").val(),qq:$('#qq').val(),message:message,power:power,ip:returnCitySN['cip'],ipadr:returnCitySN['cname'],time:gettime()},
			dataType: 'html',
			success:function(data){alert(data);window.open("./guestbook.php","_self");},
			error:function(){alert("未知错误...");window.open("./guestbook.php","_self");}
		});
	});
	
	
});



//注销
////写cookies

function setCookie(name,value)
{
    var Days = 30;
    var exp = new Date();
    exp.setTime(exp.getTime() + Days*24*60*60*1000);
    document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
} 

//读取cookies
function getCookie(name)
{
    var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
 
    if(arr=document.cookie.match(reg))
 
        return unescape(arr[2]);
    else
        return null;
}

//删除cookies
function delCookie(name)
{
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval=getCookie(name);
    if(cval!=null)
        document.cookie= name + "="+cval+";expires="+exp.toGMTString();
} 
$(document).ready(function() {
	$('#logout').click(function() {
		delCookie("username");
		alert("注销成功！");
		window.open("./index.php","_self");
	});
});