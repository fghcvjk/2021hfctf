<?php
  $id=2;
  include "../htmlport.php";
  $title= $articles[$id-1]['title'];
  $time=$articles[$id-1]['time'];
  $author=$articles[$id-1]['author'];
  $sort=$articles[$id-1]['sort'];
?>

<!DOCTYPE HTML>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title><?php echo "$title"; ?></title>
<link rel="stylesheet" href="/css/index.css"/>
<link rel="stylesheet" href="/css/style.css"/>
<script type="text/javascript" src="/js/jquery1.42.min.js"></script>
<script type="text/javascript" src="/js/jquery.SuperSlide.2.1.1.js"></script>
<style type="text/css">
a{color:#0099CC;}
a:hover{color:#99CCFF;}
br{height: 3px;}
.news_text{
  font-size: 18px;
}
</style>
</head>
<body>
    <?php  
      headerport();#header
      navport();#start 
    ?>
    <!--content start-->
    <div id="content">
       <!--left-->
         <div class="left" id="news">
           <div class="weizi">
           <div class="wz_text">当前位置：<a href="#">首页</a>><a href="#">学无止境</a>><span>文章内容</span></div>
           </div>
           <div class="news_content">
                  <div class="news_top">
                    <h1><?php echo $title; ?></h1>
                    <p>
                      <span class="left sj">时间:<?php echo Date("y-m-d",$time); ?></span><span class="left fl">分类:<?php echo $sort ?></span>
                      <span class="left author"><?php echo $author; ?></span>
                    </p>
                    <div class="clear"></div>
                  </div>
                    <div class="news_text">


<p ><strong><span style='font-family:
宋体'>利用场景：</span></strong></p>

<p >同事或朋友外出有事，电脑未锁屏离开座位。可以利用这一间隙，查看<span
lang=EN-US>Ta</span>在<span lang=EN-US>Chrome</span>浏览器上保存的账号密码</p>

<p ><strong><span style='font-family:
宋体'>查看逻辑：</span></strong></p>

<p >当我们要查看<span lang=EN-US>Chrome</span>浏览器上保存的密码时，点击显示，会弹出一个对话框来要求输入<span
lang=EN-US>Windows</span>密码来验证你的权限。</p>

<p ><span lang=EN-US><img width=671
height=435 id="图片 1"
src="/articleimage/2/image001.jpg"
alt="简单绕过Chome密码查看逻辑，查看浏览器已保存的密码"></span></p>

<p ><strong><span style='font-family:
宋体'>绕过方法：</span></strong></p>

<p >在地址栏输入<span lang=EN-US>chrome://settings/<a title="浏览关于“password”的文章">password</a>s</span>来查看所有已保存的密码列表，搜索感兴趣的目标站点。</p>

<p ><span lang=EN-US><img border=0
width=537 height=444 id="图片 2"
src="/articleimage/2/image002.jpg"
alt="简单绕过Chome密码查看逻辑，查看浏览器已保存的密码"></span></p>

<p >进入目标站点的登录页面，输入用户名前几位字符，让浏览器自动填充。右键审查元素，将密码字段的<span
lang=EN-US style='color:red'>type=”password”</span>改为<span lang=EN-US
style='color:red'>type=”text”</span>。</p>

<p ><span lang=EN-US><a title="&quot;简单绕过Chome密码查看逻辑，查看浏览器已保存的密码&quot; "
alt="简单绕过Chome密码查看逻辑，查看浏览器已保存的密码"><span style='text-decoration:none'><img
border=0 width=637 height=328 id="图片 3"
src="/articleimage/2/image003.jpg"
alt="简单绕过Chome密码查看逻辑，查看浏览器已保存的密码"></span></a></span></p>

<p ><span lang=EN-US>&nbsp;</span></p>

<p ><span lang=EN-US>&nbsp;</span></p>

<p ><span lang=EN-US><img border=0
width=538 height=443 id="图片 4"
src="/articleimage/2/image004.jpg"
alt="简单绕过Chome密码查看逻辑，查看浏览器已保存的密码"></span></p>

<p ><span lang=EN-US>OK</span>完成！</p>

<p >建议：一些重要的站点不要让浏览器记住密码，人不在电脑旁得锁屏。</p>



<br><br><br>            </div>
           </div>
     
         </div>
         <!--end left -->

         <!--right-->
         <div class="right" id="c_right">
          <?php 
            blogerport();#简介 
            lanmuboxport(); #栏目分类
            friendlink(); #友情链接
          ?>
         </div>
         <!--end  right-->
         <div class="clear"></div>
         
    </div>
    <!--content end-->
    <!--footer-->
    <?php footerport();?>
    <!--footer end-->
    <script type="text/javascript">jQuery(".lanmubox").slide({easing:"easeOutBounce",delayTime:400});</script>
    <script  type="text/javascript" src="/js/nav.js"></script>
</body>
</html>


