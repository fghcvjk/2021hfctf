<?php
  $id=5;
  include "../htmlport.php";
  $title= $articles[$id-1]['title'];
  $time=$articles[$id-1]['time'];
  $author=$articles[$id-1]['author'];
  $sort=$articles[$id-1]['sort'];
?>

<!DOCTYPE HTML>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title><?php echo "$title"; ?></title>
<link rel="stylesheet" href="/css/index.css"/>
<link rel="stylesheet" href="/css/style.css"/>
<script type="text/javascript" src="/js/jquery1.42.min.js"></script>
<script type="text/javascript" src="/js/jquery.SuperSlide.2.1.1.js"></script>
<style type="text/css">
a{color:#0099CC;}
a:hover{color:#99CCFF;}
br{height: 3px;}
.news_text{
  font-size: 18px;
}
</style>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<![endif]-->
</head>

<body>
    <?php  
      headerport();#header
      navport();#start 
    ?>
    <!--content start-->
    <div id="content">
       <!--left-->
         <div class="left" id="news">
           <div class="weizi">
           <div class="wz_text">当前位置：<a href="#">首页</a>><a href="#">学无止境</a>><span>文章内容</span></div>
           </div>
           <div class="news_content">
                  <div class="news_top">
                    <h1><?php echo $title; ?></h1>
                    <p>
                      <span class="left sj">时间:<?php echo Date("y-m-d",$time); ?></span><span class="left fl">分类:<?php echo $sort ?></span>
                      <span class="left author"><?php echo $author; ?></span>
                    </p>
                    <div class="clear"></div>
                  </div>
                    <div class="news_text"> 
<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=gb2312">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 15">
<meta name=Originator content="Microsoft Word 15">
<link rel=File-List href="/articleimage/5/filelist.xml">
<link rel=Edit-Time-Data href="/articleimage/5/editdata.mso">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
w\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>O</o:Author>
  <o:LastAuthor>O</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>2</o:TotalTime>
  <o:Created>2021-04-02T19:06:00Z</o:Created>
  <o:LastSaved>2021-04-02T19:06:00Z</o:LastSaved>
  <o:Pages>1</o:Pages>
  <o:Words>773</o:Words>
  <o:Characters>4410</o:Characters>
  <o:Lines>36</o:Lines>
  <o:Paragraphs>10</o:Paragraphs>
  <o:CharactersWithSpaces>5173</o:CharactersWithSpaces>
  <o:Version>16.00</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG/>
 </o:OfficeDocumentSettings>
</xml><![endif]-->
<link rel=themeData href="/articleimage/5/themedata.thmx">
<link rel=colorSchemeMapping href="/articleimage/5/colorschememapping.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:PunctuationKerning/>
  <w:DrawingGridVerticalSpacing>7.8 磅</w:DrawingGridVerticalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>2</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>EN-US</w:LidThemeOther>
  <w:LidThemeAsian>ZH-CN</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:SpaceForUL/>
   <w:BalanceSingleByteDoubleByteWidth/>
   <w:DoNotLeaveBackslashAlone/>
   <w:ULTrailSpace/>
   <w:DoNotExpandShiftReturn/>
   <w:AdjustLineHeightInTable/>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:EnableOpenTypeKerning/>
   <w:DontFlipMirrorIndents/>
   <w:OverrideTableStyleHps/>
   <w:UseFELayout/>
  </w:Compatibility>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="&#45;-"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/>
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="false"
  DefSemiHidden="false" DefQFormat="false" DefPriority="99"
  LatentStyleCount="371">
  <w:LsdException Locked="false" Priority="0" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 9"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 1"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 2"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 3"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 4"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 5"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 6"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 7"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 8"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 9"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footnote text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="header"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footer"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index heading"/>
  <w:LsdException Locked="false" Priority="35" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="table of figures"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="envelope address"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="envelope return"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footnote reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="line number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="page number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="endnote reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="endnote text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="table of authorities"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="macro"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="toa heading"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 5"/>
  <w:LsdException Locked="false" Priority="10" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Closing"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Signature"/>
  <w:LsdException Locked="false" Priority="1" SemiHidden="true"
   UnhideWhenUsed="true" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Message Header"/>
  <w:LsdException Locked="false" Priority="11" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Salutation"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Date"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text First Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text First Indent 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Note Heading"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Block Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Hyperlink"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="FollowedHyperlink"/>
  <w:LsdException Locked="false" Priority="22" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" Priority="20" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Document Map"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Plain Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="E-mail Signature"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Top of Form"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Bottom of Form"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal (Web)"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Acronym"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Address"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Cite"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Code"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Definition"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Keyboard"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Preformatted"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Sample"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Typewriter"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Variable"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal Table"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation subject"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="No List"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Contemporary"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Elegant"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Professional"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Subtle 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Subtle 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Web 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Web 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Web 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Balloon Text"/>
  <w:LsdException Locked="false" Priority="39" Name="Table Grid"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Theme"/>
  <w:LsdException Locked="false" SemiHidden="true" Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" SemiHidden="true" Name="Revision"/>
  <w:LsdException Locked="false" Priority="34" QFormat="true"
   Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" QFormat="true"
   Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" QFormat="true"
   Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" QFormat="true"
   Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" QFormat="true"
   Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" QFormat="true"
   Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" SemiHidden="true"
   UnhideWhenUsed="true" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="TOC Heading"/>
  <w:LsdException Locked="false" Priority="41" Name="Plain Table 1"/>
  <w:LsdException Locked="false" Priority="42" Name="Plain Table 2"/>
  <w:LsdException Locked="false" Priority="43" Name="Plain Table 3"/>
  <w:LsdException Locked="false" Priority="44" Name="Plain Table 4"/>
  <w:LsdException Locked="false" Priority="45" Name="Plain Table 5"/>
  <w:LsdException Locked="false" Priority="40" Name="Grid Table Light"/>
  <w:LsdException Locked="false" Priority="46" Name="Grid Table 1 Light"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark"/>
  <w:LsdException Locked="false" Priority="51" Name="Grid Table 6 Colorful"/>
  <w:LsdException Locked="false" Priority="52" Name="Grid Table 7 Colorful"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 1"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 1"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 1"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 2"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 2"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 2"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 3"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 3"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 3"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 4"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 4"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 4"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 5"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 5"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 5"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 6"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 6"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 6"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="46" Name="List Table 1 Light"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark"/>
  <w:LsdException Locked="false" Priority="51" Name="List Table 6 Colorful"/>
  <w:LsdException Locked="false" Priority="52" Name="List Table 7 Colorful"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 1"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 1"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 1"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 2"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 2"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 2"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 3"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 3"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 3"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 4"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 4"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 4"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 5"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 5"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 5"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 6"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 6"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 6"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 6"/>
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
  {font-family:宋体;
  panose-1:2 1 6 0 3 1 1 1 1 1;
  mso-font-alt:SimSun;
  mso-font-charset:134;
  mso-generic-font-family:auto;
  mso-font-pitch:variable;
  mso-font-signature:3 680460288 22 0 262145 0;}
@font-face
  {font-family:"Cambria Math";
  panose-1:2 4 5 3 5 4 6 3 2 4;
  mso-font-charset:1;
  mso-generic-font-family:roman;
  mso-font-pitch:variable;
  mso-font-signature:0 0 0 0 0 0;}
@font-face
  {font-family:等线;
  panose-1:2 1 6 0 3 1 1 1 1 1;
  mso-font-alt:DengXian;
  mso-font-charset:134;
  mso-generic-font-family:auto;
  mso-font-pitch:variable;
  mso-font-signature:-1610612033 953122042 22 0 262159 0;}
@font-face
  {font-family:Consolas;
  panose-1:2 11 6 9 2 2 4 3 2 4;
  mso-font-charset:0;
  mso-generic-font-family:modern;
  mso-font-pitch:fixed;
  mso-font-signature:-536869121 64767 1 0 415 0;}
@font-face
  {font-family:"\@宋体";
  panose-1:2 1 6 0 3 1 1 1 1 1;
  mso-font-charset:134;
  mso-generic-font-family:auto;
  mso-font-pitch:variable;
  mso-font-signature:3 680460288 22 0 262145 0;}
@font-face
  {font-family:"\@等线";
  panose-1:2 1 6 0 3 1 1 1 1 1;
  mso-font-charset:134;
  mso-generic-font-family:auto;
  mso-font-pitch:variable;
  mso-font-signature:-1610612033 953122042 22 0 262159 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
  {mso-style-unhide:no;
  mso-style-qformat:yes;
  mso-style-parent:"";
  margin:0cm;
  margin-bottom:.0001pt;
  text-align:justify;
  text-justify:inter-ideograph;
  mso-pagination:none;
  font-size:10.5pt;
  mso-bidi-font-size:11.0pt;
  font-family:等线;
  mso-ascii-font-family:等线;
  mso-ascii-theme-font:minor-latin;
  mso-fareast-font-family:等线;
  mso-fareast-theme-font:minor-fareast;
  mso-hansi-font-family:等线;
  mso-hansi-theme-font:minor-latin;
  mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;
  mso-font-kerning:1.0pt;}
h2
  {mso-style-priority:9;
  mso-style-unhide:no;
  mso-style-qformat:yes;
  mso-style-link:"标题 2 字符";
  mso-margin-top-alt:auto;
  margin-right:0cm;
  mso-margin-bottom-alt:auto;
  margin-left:0cm;
  mso-pagination:widow-orphan;
  mso-outline-level:2;
  font-size:18.0pt;
  font-family:宋体;
  mso-bidi-font-family:宋体;
  font-weight:bold;}
h3
  {mso-style-priority:9;
  mso-style-unhide:no;
  mso-style-qformat:yes;
  mso-style-link:"标题 3 字符";
  mso-margin-top-alt:auto;
  margin-right:0cm;
  mso-margin-bottom-alt:auto;
  margin-left:0cm;
  mso-pagination:widow-orphan;
  mso-outline-level:3;
  font-size:13.5pt;
  font-family:宋体;
  mso-bidi-font-family:宋体;
  font-weight:bold;}
a:link, span.MsoHyperlink
  {mso-style-noshow:yes;
  mso-style-priority:99;
  color:blue;
  text-decoration:underline;
  text-underline:single;}
a:visited, span.MsoHyperlinkFollowed
  {mso-style-noshow:yes;
  mso-style-priority:99;
  color:#954F72;
  mso-themecolor:followedhyperlink;
  text-decoration:underline;
  text-underline:single;}
p
  {mso-style-noshow:yes;
  mso-style-priority:99;
  mso-margin-top-alt:auto;
  margin-right:0cm;
  mso-margin-bottom-alt:auto;
  margin-left:0cm;
  mso-pagination:widow-orphan;
  font-size:12.0pt;
  font-family:宋体;
  mso-bidi-font-family:宋体;}
code
  {mso-style-noshow:yes;
  mso-style-priority:99;
  mso-ansi-font-size:12.0pt;
  mso-bidi-font-size:12.0pt;
  font-family:宋体;
  mso-ascii-font-family:宋体;
  mso-fareast-font-family:宋体;
  mso-hansi-font-family:宋体;
  mso-bidi-font-family:宋体;}
pre
  {mso-style-noshow:yes;
  mso-style-priority:99;
  mso-style-link:"HTML 预设格式 字符";
  margin:0cm;
  margin-bottom:.0001pt;
  mso-pagination:widow-orphan;
  tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
  font-size:12.0pt;
  font-family:宋体;
  mso-bidi-font-family:宋体;}
span.2
  {mso-style-name:"标题 2 字符";
  mso-style-priority:9;
  mso-style-unhide:no;
  mso-style-locked:yes;
  mso-style-link:"标题 2";
  mso-ansi-font-size:18.0pt;
  mso-bidi-font-size:18.0pt;
  font-family:宋体;
  mso-ascii-font-family:宋体;
  mso-fareast-font-family:宋体;
  mso-hansi-font-family:宋体;
  mso-bidi-font-family:宋体;
  mso-font-kerning:0pt;
  font-weight:bold;}
span.3
  {mso-style-name:"标题 3 字符";
  mso-style-priority:9;
  mso-style-unhide:no;
  mso-style-locked:yes;
  mso-style-link:"标题 3";
  mso-ansi-font-size:13.5pt;
  mso-bidi-font-size:13.5pt;
  font-family:宋体;
  mso-ascii-font-family:宋体;
  mso-fareast-font-family:宋体;
  mso-hansi-font-family:宋体;
  mso-bidi-font-family:宋体;
  mso-font-kerning:0pt;
  font-weight:bold;}
p.line, li.line, div.line
  {mso-style-name:line;
  mso-style-unhide:no;
  mso-margin-top-alt:auto;
  margin-right:0cm;
  mso-margin-bottom-alt:auto;
  margin-left:0cm;
  mso-pagination:widow-orphan;
  font-size:12.0pt;
  font-family:宋体;
  mso-bidi-font-family:宋体;}
span.HTML
  {mso-style-name:"HTML 预设格式 字符";
  mso-style-noshow:yes;
  mso-style-priority:99;
  mso-style-unhide:no;
  mso-style-locked:yes;
  mso-style-link:"HTML 预设格式";
  mso-ansi-font-size:12.0pt;
  mso-bidi-font-size:12.0pt;
  font-family:宋体;
  mso-ascii-font-family:宋体;
  mso-fareast-font-family:宋体;
  mso-hansi-font-family:宋体;
  mso-bidi-font-family:宋体;
  mso-font-kerning:0pt;}
span.hljs-builtin
  {mso-style-name:hljs-built_in;
  mso-style-unhide:no;}
span.hljs-comment
  {mso-style-name:hljs-comment;
  mso-style-unhide:no;}
span.hljs-variable
  {mso-style-name:hljs-variable;
  mso-style-unhide:no;}
span.hljs-string
  {mso-style-name:hljs-string;
  mso-style-unhide:no;}
.MsoChpDefault
  {mso-style-type:export-only;
  mso-default-props:yes;
  font-family:等线;
  mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;}
 /* Page Definitions */
 @page
  {mso-page-border-surround-header:no;
  mso-page-border-surround-footer:no;}
@page WordSection1
  {size:595.3pt 841.9pt;
  margin:72.0pt 90.0pt 72.0pt 90.0pt;
  mso-header-margin:42.55pt;
  mso-footer-margin:49.6pt;
  mso-paper-source:0;
  layout-grid:15.6pt;}
div.WordSection1
  {page:WordSection1;}
 /* List Definitions */
 @list l0
  {mso-list-id:823667855;
  mso-list-template-ids:1684031208;}
@list l0:level1
  {mso-level-start-at:9;
  mso-level-tab-stop:36.0pt;
  mso-level-number-position:left;
  text-indent:-18.0pt;}
@list l1
  {mso-list-id:1389181177;
  mso-list-template-ids:-275767500;}
@list l1:level1
  {mso-level-start-at:5;
  mso-level-tab-stop:36.0pt;
  mso-level-number-position:left;
  text-indent:-18.0pt;}
@list l2
  {mso-list-id:1410350664;
  mso-list-template-ids:448061078;}
@list l2:level1
  {mso-level-start-at:6;
  mso-level-tab-stop:36.0pt;
  mso-level-number-position:left;
  text-indent:-18.0pt;}
@list l3
  {mso-list-id:1455439974;
  mso-list-template-ids:1978185904;}
@list l3:level1
  {mso-level-start-at:10;
  mso-level-tab-stop:36.0pt;
  mso-level-number-position:left;
  text-indent:-18.0pt;}
@list l4
  {mso-list-id:1568490318;
  mso-list-template-ids:-1546882642;}
@list l4:level1
  {mso-level-start-at:7;
  mso-level-tab-stop:36.0pt;
  mso-level-number-position:left;
  text-indent:-18.0pt;}
@list l5
  {mso-list-id:1921255686;
  mso-list-template-ids:-1595219306;}
@list l5:level1
  {mso-level-start-at:4;
  mso-level-tab-stop:36.0pt;
  mso-level-number-position:left;
  text-indent:-18.0pt;}
@list l6
  {mso-list-id:1967001388;
  mso-list-template-ids:-2076800250;}
ol
  {margin-bottom:0cm;}
ul
  {margin-bottom:0cm;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
  {mso-style-name:普通表格;
  mso-tstyle-rowband-size:0;
  mso-tstyle-colband-size:0;
  mso-style-noshow:yes;
  mso-style-priority:99;
  mso-style-parent:"";
  mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
  mso-para-margin:0cm;
  mso-para-margin-bottom:.0001pt;
  mso-pagination:widow-orphan;
  font-size:10.5pt;
  mso-bidi-font-size:11.0pt;
  font-family:等线;
  mso-ascii-font-family:等线;
  mso-ascii-theme-font:minor-latin;
  mso-fareast-font-family:等线;
  mso-fareast-theme-font:minor-fareast;
  mso-hansi-font-family:等线;
  mso-hansi-theme-font:minor-latin;
  mso-font-kerning:1.0pt;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=ZH-CN link=blue vlink="#954F72" style='tab-interval:21.0pt;
text-justify-trim:punctuation'>

<div class=WordSection1 style='layout-grid:15.6pt'>

<p class=MsoNormal align=left style='margin-bottom:11.25pt;text-align:left;
mso-pagination:widow-orphan;mso-outline-level:2;background:white'><b><span
style='font-size:18.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;mso-font-kerning:0pt'>前言</span></b><b><span
lang=EN-US style='font-size:18.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;mso-font-kerning:0pt'><o:p></o:p></span></b></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>Z2blog </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>作为静态博客的渣滓，至今已经有好几年历史，而且一直没有在更新发展中，功能弱鸡，插件和主题没有，不过</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>Z2blog</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>搭建使用却很方便。作为个人站长和博主的我，就是从</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> Z2blog </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>入门的。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>本文为零基础</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> Z2blog </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>建站教程，手把手教你从零开始搭建</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> Z2blog </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>个人博客。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:11.25pt;text-align:left;
mso-pagination:widow-orphan;mso-outline-level:2;background:white'><b><span
style='font-size:18.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;mso-font-kerning:0pt'>简介</span></b><b><span
lang=EN-US style='font-size:18.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;mso-font-kerning:0pt'><o:p></o:p></span></b></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>Z2blog </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>（简称</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> zz</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>）可以说是全球最不流行的博客系统了，没有之一，世界上约</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> 0.000000001% </span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>的网站都是基于</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> zz </span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>搭建的。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>相比于之前介绍的轻量版博客程序</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> Typecho</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>zz </span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>则是将所有功能集于一体，是个一体化的内容发布平台，不自带主题和插件市场，当然也不能直接在后台完成所有网站建设工作。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>如果把</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> Typecho </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>比作沙县小吃的话，那</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> zz </span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>就是街头小炸。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:11.25pt;text-align:left;
mso-pagination:widow-orphan;mso-outline-level:2;background:white'><b><span
style='font-size:18.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;mso-font-kerning:0pt'>概览</span></b><b><span
lang=EN-US style='font-size:18.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;mso-font-kerning:0pt'><o:p></o:p></span></b></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>建议先浏览一遍全文，大概了解下再开始搭建，估计需要</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> 5-30 </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>分钟完成。小白请严格按照步骤来，不要漏了。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:11.25pt;text-align:left;
mso-pagination:widow-orphan;mso-outline-level:3;background:white'><b><span
style='font-size:16.5pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;mso-font-kerning:0pt'>需要准备：</span></b><b><span
lang=EN-US style='font-size:16.5pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;mso-font-kerning:0pt'><o:p></o:p></span></b></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>聪慧的头脑：推荐一个大脑即可，如果有多余更佳</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><br>
</span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;
mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>支付方式：</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'>IC</span><span style='font-size:12.0pt;font-family:宋体;
mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:
Arial;color:#333333;mso-font-kerning:0pt'>、</span><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>IE</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>、</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>IQ</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>卡</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><br>
</span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;
mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>笔记本：记录好账号信息和数据库信息</span><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:11.25pt;text-align:left;
mso-pagination:widow-orphan;mso-outline-level:3;background:white'><b><span
style='font-size:16.5pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;mso-font-kerning:0pt'>步骤：</span></b><b><span
lang=EN-US style='font-size:16.5pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;mso-font-kerning:0pt'><o:p></o:p></span></b></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>注册域名</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><br>
</span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;
mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>创建</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'> VPS<br>
</span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;
mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>域名解析（重要！）</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'><br>
</span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;
mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>连接</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'> VPS<br>
</span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;
mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>搭建</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'> zz<br>
</span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;
mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>基本使用</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'><br>
6.1 </span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:
Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>发布文章</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'><br>
6.2 </span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:
Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>主题安装</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'><br>
6.3 </span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:
Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>插件安装</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'><br>
</span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;
mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>常见问题</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'> &amp; </span><span style='font-size:12.0pt;font-family:
宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:
Arial;color:#333333;mso-font-kerning:0pt'>解决</span><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:11.25pt;text-align:left;
mso-pagination:widow-orphan;mso-outline-level:2;background:white'><b><span
style='font-size:18.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;mso-font-kerning:0pt'>以上全都不教</span></b><b><span
lang=EN-US style='font-size:18.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;mso-font-kerning:0pt'><o:p></o:p></span></b></p>

<div class=MsoNormal align=center style='margin-bottom:15.0pt;text-align:center;
mso-pagination:widow-orphan'><span lang=EN-US style='font-size:12.0pt;
font-family:宋体;mso-bidi-font-family:宋体;mso-font-kerning:0pt'>

<hr size=0 width="100%" noshade style='color:#333333' align=center>

</span></div>

<p class=MsoNormal align=left style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:12.0pt;margin-left:18.0pt;text-align:left;text-indent:-18.0pt;
line-height:22.5pt;mso-pagination:widow-orphan;mso-list:l6 level1 lfo1;
tab-stops:list 36.0pt;background:white'><![if !supportLists]><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
Arial;color:#333333;mso-font-kerning:0pt'><span style='mso-list:Ignore'>1.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>准备好一个自己的公网服务器（过程略），预装好</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> Linux </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>系统（推荐</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> ubuntu 20.04</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>）。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><br>
</span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;
mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>更换源，个人推荐使用阿里云源</span><span lang=EN-US style='font-size:
12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:12.0pt;margin-left:18.0pt;text-align:left;text-indent:-18.0pt;
line-height:22.5pt;mso-pagination:widow-orphan;mso-list:l6 level1 lfo1;
tab-stops:list 36.0pt;background:white'><![if !supportLists]><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
Arial;color:#333333;mso-font-kerning:0pt'><span style='mso-list:Ignore'>2.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>源码级安装</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>docker </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>或者使用方法</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>&nbsp;</span><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;background:#F6F6F6;mso-font-kerning:0pt'>apt
install docker.io</span><span lang=EN-US style='font-size:12.0pt;font-family:
"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:
0pt'>&nbsp;</span><span style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:
Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:Arial;color:#333333;
mso-font-kerning:0pt'>安装</span><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:宋体;color:#333333;
mso-font-kerning:0pt'>docker</span><span style='font-size:12.0pt;font-family:
宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:
Arial;color:#333333;mso-font-kerning:0pt'>，</span><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:12.0pt;margin-left:18.0pt;text-align:left;text-indent:-18.0pt;
line-height:22.5pt;mso-pagination:widow-orphan;mso-list:l6 level1 lfo1;
tab-stops:list 36.0pt;background:white'><![if !supportLists]><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
Arial;color:#333333;mso-font-kerning:0pt'><span style='mso-list:Ignore'>3.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>使用</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>docker</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>获取一个</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>ubuntu 16.04</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>镜像。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><br>
docker pull ubuntu:16.04<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:12.0pt;margin-left:18.0pt;text-align:left;text-indent:-18.0pt;
line-height:22.5pt;mso-pagination:widow-orphan;mso-list:l6 level1 lfo1;
tab-stops:list 36.0pt;background:white'><![if !supportLists]><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
Arial;color:#333333;mso-font-kerning:0pt'><span style='mso-list:Ignore'>4.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>源码级安装</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> nginx</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，过程略。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;margin-left:18.0pt;text-align:left;text-indent:-18.0pt;line-height:22.5pt;
mso-pagination:widow-orphan;mso-list:l5 level1 lfo2;tab-stops:list 36.0pt;
background:white'><![if !supportLists]><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:#333333;
mso-font-kerning:0pt'><span style='mso-list:Ignore'>4.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span style='font-size:12.0pt;font-family:宋体;
mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:
Arial;color:#333333;mso-font-kerning:0pt'>从</span><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>git.php.net</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>获取</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>php-src</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>代码。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shapetype id="_x0000_t75" coordsize="21600,21600"
 o:spt="75" o:preferrelative="t" path="m@4@5l@4@11@9@11@9@5xe" filled="f"
 stroked="f">
 <v:stroke joinstyle="miter"/>
 <v:formulas>
  <v:f eqn="if lineDrawn pixelLineWidth 0"/>
  <v:f eqn="sum @0 1 0"/>
  <v:f eqn="sum 0 0 @1"/>
  <v:f eqn="prod @2 1 2"/>
  <v:f eqn="prod @3 21600 pixelWidth"/>
  <v:f eqn="prod @3 21600 pixelHeight"/>
  <v:f eqn="sum @0 0 1"/>
  <v:f eqn="prod @6 1 2"/>
  <v:f eqn="prod @7 21600 pixelWidth"/>
  <v:f eqn="sum @8 21600 0"/>
  <v:f eqn="prod @7 21600 pixelHeight"/>
  <v:f eqn="sum @10 21600 0"/>
 </v:formulas>
 <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
 <o:lock v:ext="edit" aspectratio="t"/>
</v:shapetype><v:shape id="图片_x0020_20" o:spid="_x0000_i1045" type="#_x0000_t75"
 alt="image.png" style='width:709.5pt;height:184.5pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image001.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img width=946 height=246
src="/articleimage/5/image001.png" alt=image.png v:shapes="图片_x0020_20"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>运行</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> buildconf </span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>脚本，会自动生成</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>configure</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，但是提示需要安装</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>autoconf</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，那么我们按照要求使用</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> apt </span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>安装</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='text-align:left;mso-pagination:widow-orphan'><span
lang=EN-US style='font-size:12.0pt;font-family:宋体;mso-bidi-font-family:宋体;
mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_19" o:spid="_x0000_i1044" type="#_x0000_t75"
 alt="image.png" style='width:618.75pt;height:98.25pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image002.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img width=825 height=131
src="/articleimage/5/image002.png" alt=image.png v:shapes="图片_x0020_19"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>此时已经成功生成了</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> configure </span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>文件</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='text-align:left;mso-pagination:widow-orphan'><span
lang=EN-US style='font-size:12.0pt;font-family:宋体;mso-bidi-font-family:宋体;
mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_18" o:spid="_x0000_i1043" type="#_x0000_t75"
 alt="image.png" style='width:681.75pt;height:153.75pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image003.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img width=909 height=205
src="/articleimage/5/image003.png" alt=image.png v:shapes="图片_x0020_18"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;margin-left:18.0pt;text-align:left;text-indent:-18.0pt;line-height:22.5pt;
mso-pagination:widow-orphan;mso-list:l1 level1 lfo3;tab-stops:list 36.0pt;
background:white'><![if !supportLists]><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:#333333;
mso-font-kerning:0pt'><span style='mso-list:Ignore'>5.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span style='font-size:12.0pt;font-family:宋体;
mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:
Arial;color:#333333;mso-font-kerning:0pt'>到这里是不是以为只要</span><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> ./configure </span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，等待程序配置完成，我们再使用</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> make &amp;&amp; make install </span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>就可以万事大吉了？不不不，更多的坑还在等着我们呢</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>执行命令</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;background:#F6F6F6;mso-font-kerning:
0pt'>./configure --enable-fpm --with-mysql --with-zlib</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，等待配置完成。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>然后很快阿，第一个问题就来了</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='text-align:left;mso-pagination:widow-orphan'><span
lang=EN-US style='font-size:12.0pt;font-family:宋体;mso-bidi-font-family:宋体;
mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_17" o:spid="_x0000_i1042" type="#_x0000_t75"
 alt="image.png" style='width:614.25pt;height:267pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image004.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img width=819 height=356
src="/articleimage/5/image004.png" alt=image.png v:shapes="图片_x0020_17"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>看起来是没有</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>C</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>的编译环境，那么妥了，</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>gcc</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>一把梭走起</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> apt install gcc</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>。问题解决，</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>beautiful~<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>刚想庆幸一会，没想到下一个问题就紧接着来了。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>configure: error: bison 3.0.0 is
required to generate PHP parsers (excluded versions: none).<o:p></o:p></span></p>

<p class=MsoNormal align=left style='text-align:left;mso-pagination:widow-orphan'><span
lang=EN-US style='font-size:12.0pt;font-family:宋体;mso-bidi-font-family:宋体;
mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_16" o:spid="_x0000_i1041" type="#_x0000_t75"
 alt="image.png" style='width:804.75pt;height:267.75pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image005.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img width=1073 height=357
src="/articleimage/5/image005.png" alt=image.png v:shapes="图片_x0020_16"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>这个根据描述，应该就是缺少</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> bison </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，跟上面一样</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> apt </span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>安装即可。然后我们继续，得，又出现一个相似的问题，缺少</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>re2c</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，你说说这个</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>php</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，不讲武德，来偷袭，还一个一个的来。我劝你耗子尾汁。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='text-align:left;mso-pagination:widow-orphan'><span
lang=EN-US style='font-size:12.0pt;font-family:宋体;mso-bidi-font-family:宋体;
mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_15" o:spid="_x0000_i1040" type="#_x0000_t75"
 alt="image.png" style='width:702.75pt;height:117pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image006.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img width=937 height=156
src="/articleimage/5/image006.png" alt=image.png v:shapes="图片_x0020_15"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>继续</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>apt</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>安装</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>re2c</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，重来，这次倒是跑了很久，然后弹出了一个奇怪的问题。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='text-align:left;mso-pagination:widow-orphan'><span
lang=EN-US style='font-size:12.0pt;font-family:宋体;mso-bidi-font-family:宋体;
mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_14" o:spid="_x0000_i1039" type="#_x0000_t75"
 alt="image.png" style='width:798pt;height:325.5pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image007.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img width=1064 height=434
src="/articleimage/5/image007.png" alt=image.png v:shapes="图片_x0020_14"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>我的老天鹅，缺少包就够了，还来这么多英语，欺负我四级没过？我上来就是一手</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> apt install libxml</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，不行？在一手</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> apt install libxml2</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，我今天就想看看，我还有一个</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> apt install libxml-2</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>、一张</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> apt install libxml-2.0</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，你今天是怎么秒我？？？你要是能秒掉我，我！今！天！当场把这个镜像吃掉！！！</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_13" o:spid="_x0000_i1038" type="#_x0000_t75"
 alt="image.png" style='width:590.25pt;height:484.5pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image008.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img width=787 height=646
src="/articleimage/5/image008.png" alt=image.png v:shapes="图片_x0020_13"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>嗯？？？现在的年轻人不讲武德，来骗，偷袭我这个单纯的程序猿。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>没事，最后一记绝招，</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>apt search libxml<o:p></o:p></span></p>

<p class=MsoNormal align=left style='text-align:left;mso-pagination:widow-orphan'><span
lang=EN-US style='font-size:12.0pt;font-family:宋体;mso-bidi-font-family:宋体;
mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_12" o:spid="_x0000_i1037" type="#_x0000_t75"
 alt="image.png" style='width:685.5pt;height:689.25pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image009.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img width=914 height=919
src="/articleimage/5/image009.png" alt=image.png v:shapes="图片_x0020_12"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>擦，这么多包，这能装到什么时候，猴年马月的，我告诉你</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>php</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，我今天要不是给你个面子，今天我就当场</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>apt install libxml* </span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>了，你信不信。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;margin-left:18.0pt;text-align:left;text-indent:-18.0pt;line-height:22.5pt;
mso-pagination:widow-orphan;mso-list:l2 level1 lfo4;tab-stops:list 36.0pt;
background:white'><![if !supportLists]><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:#333333;
mso-font-kerning:0pt'><span style='mso-list:Ignore'>6.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span style='font-size:12.0pt;font-family:宋体;
mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:
Arial;color:#333333;mso-font-kerning:0pt'>我认怂，我错了行不行，百度爸爸求你给我个答案，</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><a
href="https://www.cnblogs.com/Anker/p/3542058.html" target="_blank"><span
style='color:#3194D0'>https://www.cnblogs.com/Anker/p/3542058.html</span></a></span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>、</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><a
href="https://blog.csdn.net/shanzhizi/article/details/7726679" target="_blank"><span
style='color:#3194D0'>https://blog.csdn.net/shanzhizi/article/details/7726679</span></a></span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，这</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>libxml</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>也是源码级安装的？</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;text-align:center;line-height:22.5pt;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_11" o:spid="_x0000_i1036" type="#_x0000_t75"
 alt="image.png" style='width:735.75pt;height:603.75pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image010.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=981 height=805
src="/articleimage/5/image010.png" alt=image.png v:shapes="图片_x0020_11"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;text-align:center;mso-pagination:widow-orphan;background:white'><span
lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;margin-left:15.0pt;text-align:left;line-height:22.5pt;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;text-align:center;line-height:22.5pt;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_10" o:spid="_x0000_i1035" type="#_x0000_t75"
 alt="image.png" style='width:528.75pt;height:514.5pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image011.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=705 height=686
src="/articleimage/5/image011.png" alt=image.png v:shapes="图片_x0020_10"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;text-align:center;mso-pagination:widow-orphan;background:white'><span
lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>然后就去官网下载源码，捣鼓代码去了，但是万万没想到阿，装了的版本是</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>libxml 2.6</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>的，不知道大家注意到开始的配置检查了吗，需要大于等于</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> 2.9.0 </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>才行。。。。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>难道我就只能继续重新安装</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>libxml</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>了吗？不，肯定有更好的办法！</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>于是经过我的不懈努力（</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>zixiguancha</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>），原来第二篇文章的后面部分还写了第二种安装方法，我说兄弟，你这就没意思了，明明有更简单的方法，非要把最复杂的一种放在开头。。。此时仿佛有一万头草泥马从我头上奔过。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_9" o:spid="_x0000_i1034" type="#_x0000_t75"
 alt="image.png" style='width:324.75pt;height:201pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image012.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=433 height=268
src="/articleimage/5/image012.png" alt=image.png v:shapes="图片_x0020_9"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>按照要求安装</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> libxml2-dev<o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_8" o:spid="_x0000_i1033" type="#_x0000_t75"
 alt="image.png" style='width:651pt;height:566.25pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image013.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=868 height=755
src="/articleimage/5/image013.png" alt=image.png v:shapes="图片_x0020_8"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:12.0pt;margin-left:18.0pt;text-align:left;text-indent:-18.0pt;
line-height:22.5pt;mso-pagination:widow-orphan;mso-list:l4 level1 lfo5;
tab-stops:list 36.0pt;background:white'><![if !supportLists]><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
Arial;color:#333333;mso-font-kerning:0pt'><span style='mso-list:Ignore'>7.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>然后居然还卡在这儿了，仔细一看，我擦，原来是下面的地方出问题了，不是</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>libxml</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>的问题，靠靠靠。。。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;margin-left:15.0pt;text-align:left;line-height:22.5pt;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;text-align:center;line-height:22.5pt;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_7" o:spid="_x0000_i1032" type="#_x0000_t75"
 alt="image.png" style='width:591pt;height:350.25pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image014.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=788 height=467
src="/articleimage/5/image014.png" alt=image.png v:shapes="图片_x0020_7"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;text-align:center;mso-pagination:widow-orphan;background:white'><span
lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>百度大法还是好，很快解决问题。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='text-align:left;mso-pagination:widow-orphan'><span
lang=EN-US style='font-size:12.0pt;font-family:宋体;mso-bidi-font-family:宋体;
mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_6" o:spid="_x0000_i1031" type="#_x0000_t75"
 alt="image.png" style='width:621.75pt;height:792.75pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image015.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=829 height=1057
src="/articleimage/5/image015.png" alt=image.png v:shapes="图片_x0020_6"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>让我们继续完成</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>php</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>源码安装的大业，喔嚯，果不其然，还有一个</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>sqlite3</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>的问题在埋伏着我们。反手就是一行</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> apt install sqlite3</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>解决战斗，什么？居然还没解决问题。装了</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>sqlite3</span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>还是不行？我这版本都</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>3.11</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>了，怎么也比你这个要求的</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>3.7</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>大吧？！</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_5" o:spid="_x0000_i1030" type="#_x0000_t75"
 alt="image.png" style='width:563.25pt;height:213pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image016.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=751 height=284
src="/articleimage/5/image016.png" alt=image.png v:shapes="图片_x0020_5"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='text-align:left;mso-pagination:widow-orphan'><span
lang=EN-US style='font-size:12.0pt;font-family:宋体;mso-bidi-font-family:宋体;
mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_4" o:spid="_x0000_i1029" type="#_x0000_t75"
 alt="image.png" style='width:553.5pt;height:54pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image017.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=738 height=72
src="/articleimage/5/image017.png" alt=image.png v:shapes="图片_x0020_4"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>继续百度大法，哦，原来是还得装</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>libsqlite3-dev</span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>，得得得，把你们兄弟俩一起装好，和和美美，让我们继续。。。</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>终于没在让我们难受，出现了欢迎界面</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_3" o:spid="_x0000_i1028" type="#_x0000_t75"
 alt="image.png" style='width:557.25pt;height:540pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image018.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=743 height=720
src="/articleimage/5/image018.png" alt=image.png v:shapes="图片_x0020_3"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:18.75pt;text-align:left;
mso-pagination:widow-orphan;background:white'><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>8 </span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>。接下来就是大快人心的</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> make &amp;&amp; make install </span><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>环节，很完美昂，很完美</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='text-align:left;mso-pagination:widow-orphan'><span
lang=EN-US style='font-size:12.0pt;font-family:宋体;mso-bidi-font-family:宋体;
mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_2" o:spid="_x0000_i1027" type="#_x0000_t75"
 alt="image.png" style='width:595.5pt;height:573.75pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image019.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=794 height=765
src="/articleimage/5/image019.png" alt=image.png v:shapes="图片_x0020_2"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='text-align:center;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal align=left style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;margin-left:18.0pt;text-align:left;text-indent:-18.0pt;line-height:22.5pt;
mso-pagination:widow-orphan;mso-list:l0 level1 lfo6;tab-stops:list 36.0pt;
background:white'><![if !supportLists]><span lang=EN-US style='font-size:12.0pt;
font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:#333333;
mso-font-kerning:0pt'><span style='mso-list:Ignore'>9.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span style='font-size:12.0pt;font-family:宋体;
mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;mso-bidi-font-family:
Arial;color:#333333;mso-font-kerning:0pt'>装好</span><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>php</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>之后，还得继续配置</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>php</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>相关信息，以及安装</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>nginx</span><span style='font-size:12.0pt;
font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>。具体方法参考官网链接：</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><a
href="https://www.php.net/manual/zh/install.unix.nginx.php" target="_blank"><span
style='color:#3194D0'>https://www.php.net/manual/zh/install.unix.nginx.php</span></a><o:p></o:p></span></p>

<div style='mso-element:para-border-div;border:solid #D9D9D9 1.0pt;mso-border-alt:
solid #D9D9D9 .75pt;padding:8.0pt 8.0pt 8.0pt 8.0pt;background:#282C34'>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>1.<span
style='mso-spacerun:yes'>&nbsp; </span></span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>建议您访问</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> Nginx Wiki [&raquo; </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>安装</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'>](https://www.nginx.com/resources/wiki/start/topics/tutorials/install/)
</span><span style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>页面以获取并在您的系统上安装</span><span lang=EN-US style='font-size:
9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:
宋体;color:#C7254E;mso-font-kerning:0pt'> Nginx</span><span style='font-size:
9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>。</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>2.<span
style='mso-spacerun:yes'>&nbsp; </span></span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>获取并解压</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> PHP </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>源代码</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'>:<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>tar zxf php-x.x.x<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>3.<span
style='mso-spacerun:yes'>&nbsp; </span></span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>配置并构建</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> PHP</span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>。在此步骤您可以使用很多选项自定义</span><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> PHP</span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>，例如启用某些扩展等。</span><span style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> </span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>运行</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> ./configure --</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>help</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>命令来获得完整的可用选项清单。</span><span style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> </span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>在本示例中，我们仅进行包含</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> PHP-FPM </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>和</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> MySQL </span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>支持的简单配置。</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>cd</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> ../php-x.x.x<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>./configure --</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>enable</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>-fpm
--with-mysql<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>make<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>sudo make install<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>4.<span
style='mso-spacerun:yes'>&nbsp; </span></span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>创建配置文件，并将其复制到正确的位置。</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>cp php.ini-development /usr/</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/php/php.ini<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>cp /usr/</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/etc/php-fpm.d/www.conf.default
/usr/</span><span lang=EN-US style='font-size:9.0pt;font-family:Consolas;
mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:
0pt'>local</span><span lang=EN-US style='font-size:9.0pt;font-family:Consolas;
mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:
0pt'>/etc/php-fpm.d/www.conf<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>cp sapi/fpm/php-fpm /usr/</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/bin<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>5.<span
style='mso-spacerun:yes'>&nbsp; </span></span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>需要着重提醒的是，如果文件不存在，则阻止</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> Nginx </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>将请求发送到后端的</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> PHP-FPM </span><span style='font-size:
9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>模块，</span><span
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>以避免遭受恶意脚本注入的攻击。</span><span lang=EN-US style='font-size:
9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:
宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>将</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> php.ini </span><span style='font-size:
9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>文件中的配置项</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>
[cgi.fix_pathinfo](https://www.php.net/manual/zh/ini.core.php</span><i><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#5C6370;mso-font-kerning:0pt'>#ini.cgi.fix-pathinfo)
</span></i><i><span style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:
Consolas;mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#5C6370;
mso-font-kerning:0pt'>设置为</span></i><i><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#5C6370;mso-font-kerning:0pt'> `0` </span></i><i><span style='font-size:
9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#5C6370;mso-font-kerning:0pt'>。</span></i><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>打开</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> php.ini:<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>vim /usr/</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/php/php.ini<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>定位到</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> `cgi.fix_pathinfo=` </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>并将其修改为如下所示：</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>cgi.fix_pathinfo=0<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>6.<span
style='mso-spacerun:yes'>&nbsp; </span></span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>在启动服务之前，需要修改</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> php-fpm.conf </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>配置文件，确保</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> php-fpm </span><span style='font-size:
9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>模块使用</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> www-data </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>用户和</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> www-data </span><span style='font-size:
9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>用户组的身份运行。</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>vim /usr/</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/etc/php-fpm.d/www.conf<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>找到以下内容并修改：</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>; Unix user/group of
processes<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>; Note: The user is
mandatory. If the group is not </span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#E6C07B;mso-font-kerning:0pt'>set</span><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>, the default users
group<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>;<span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>will be
used.<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>user = www-data<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>group = www-data<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>然后启动</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> php-fpm </span><span style='font-size:
9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>服务：</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>/usr/</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/bin/php-fpm<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>本文档未涵盖对</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> php-fpm </span><span style='font-size:
9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>进行进一步配置的信息，如果您需要更多信息，请查阅相关文档。</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>7.<span
style='mso-spacerun:yes'>&nbsp; </span></span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>配置</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> Nginx </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>使其支持</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> PHP </span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>应用：</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>vim /usr/</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/nginx/conf/nginx.conf<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>修改默认的</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> location </span><span style='font-size:
9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>块，使其支持</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> .php </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>文件：</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>location / {<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span>root<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>html;<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span
style='mso-spacerun:yes'>&nbsp;&nbsp;</span>index<span
style='mso-spacerun:yes'>&nbsp; </span>index.php index.html index.htm;<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>}<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>下一步配置来保证对于</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> .php </span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>文件的请求将被传送到后端的</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> PHP-FPM </span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>模块，</span><span style='font-size:9.0pt;font-family:Consolas;
mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:
0pt'> </span><span style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:
Consolas;mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>取消默认的</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> PHP </span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>配置块的注释，并修改为下面的内容：</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>location ~* \.php$ {<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span>fastcgi_index<span style='mso-spacerun:yes'>&nbsp;&nbsp;
</span>index.php;<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span>fastcgi_pass<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;
</span>127.0.0.1:9000;<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span>include<span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span>fastcgi_params;<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span>fastcgi_param<span style='mso-spacerun:yes'>&nbsp;&nbsp;
</span>SCRIPT_FILENAME<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#D19A66;mso-font-kerning:0pt'>$document_root$fastcgi_script_name</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>;<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span>fastcgi_param<span style='mso-spacerun:yes'>&nbsp;&nbsp;
</span>SCRIPT_NAME<span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#D19A66;mso-font-kerning:0pt'>$fastcgi_script_name</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>;<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>}<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>重启</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> Nginx</span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>。</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>sudo /usr/</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/nginx/sbin/nginx
-s stop<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>sudo /usr/</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/nginx/sbin/nginx<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>8.<span
style='mso-spacerun:yes'>&nbsp; </span></span><span style='font-size:9.0pt;
font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>创建测试文件。</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>rm /usr/</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/nginx/html/index.html<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>echo</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'> </span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#98C379;mso-font-kerning:0pt'>&quot;&lt;?php
phpinfo(); ?&gt;&quot;</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> &gt;&gt; /usr/</span><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#E6C07B;mso-font-kerning:0pt'>local</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>/nginx/html/index.php<o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><span
style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>打开浏览器，访问</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> http://localhost</span><span
style='font-size:9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;
mso-hansi-font-family:Consolas;mso-bidi-font-family:宋体;color:#C7254E;
mso-font-kerning:0pt'>，将会显示</span><span lang=EN-US style='font-size:9.0pt;
font-family:Consolas;mso-fareast-font-family:宋体;mso-bidi-font-family:宋体;
color:#C7254E;mso-font-kerning:0pt'> phpinfo() </span><span style='font-size:
9.0pt;font-family:宋体;mso-ascii-font-family:Consolas;mso-hansi-font-family:Consolas;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'>。</span><span
lang=EN-US style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:
宋体;mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=left style='margin-bottom:15.0pt;text-align:left;
line-height:15.0pt;mso-pagination:widow-orphan;tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
background:#282C34;word-break:break-all;border:none;mso-border-alt:solid #D9D9D9 .75pt;
padding:0cm;mso-padding-alt:8.0pt 8.0pt 8.0pt 8.0pt'><span lang=EN-US
style='font-size:9.0pt;font-family:Consolas;mso-fareast-font-family:宋体;
mso-bidi-font-family:宋体;color:#C7254E;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

</div>

<p class=MsoNormal align=left style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:12.0pt;margin-left:18.0pt;text-align:left;text-indent:-18.0pt;
line-height:22.5pt;mso-pagination:widow-orphan;mso-list:l3 level1 lfo7;
tab-stops:list 36.0pt;background:white'><![if !supportLists]><span lang=EN-US
style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
Arial;color:#333333;mso-font-kerning:0pt'><span style='mso-list:Ignore'>10.<span
style='font:7.0pt "Times New Roman"'> </span></span></span><![endif]><span
style='font-size:12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:
Arial;mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>最后一步当然是部署博客代码啦，博客代码可以从</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'> xxxx </span><span style='font-size:
12.0pt;font-family:宋体;mso-ascii-font-family:Arial;mso-hansi-font-family:Arial;
mso-bidi-font-family:Arial;color:#333333;mso-font-kerning:0pt'>获取，大家下载下来之后直接放到服务器上就可以啦</span><span
lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'>~~<o:p></o:p></span></p>

<p class=MsoNormal align=left style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;margin-left:15.0pt;text-align:left;line-height:22.5pt;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;text-align:center;line-height:22.5pt;mso-pagination:widow-orphan;
background:white'><span lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;
mso-fareast-font-family:宋体;color:#333333;mso-font-kerning:0pt;mso-no-proof:
yes'><!--[if gte vml 1]><v:shape id="图片_x0020_1" o:spid="_x0000_i1026" type="#_x0000_t75"
 alt="image.png" style='width:849pt;height:711.75pt;visibility:visible;
 mso-wrap-style:square'>
 <v:imagedata src="/articleimage/5/image020.png" o:title="image"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=1132 height=949
src="/articleimage/5/image020.png" alt=image.png v:shapes="图片_x0020_1"><![endif]></span><span
lang=EN-US style='font-size:1.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#333333;mso-font-kerning:0pt'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
auto;text-align:center;mso-pagination:widow-orphan;background:white'><span
lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
宋体;color:#999999;mso-font-kerning:0pt'>image.png<o:p></o:p></span></p>

<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>

</div>

</body>

</html>


<br><br><br>
            </div>
           </div>
     
         </div>
         <!--end left -->

         <!--right-->
         <div class="right" id="c_right">
          <?php 
            blogerport();#简介 
            lanmuboxport(); #栏目分类
            friendlink(); #友情链接
          ?>
         </div>
         <!--end  right-->
         <div class="clear"></div>
         
    </div>
    <!--content end-->
    <!--footer-->
    <?php footerport();?>
    <!--footer end-->
    <script type="text/javascript">jQuery(".lanmubox").slide({easing:"easeOutBounce",delayTime:400});</script>
    <script  type="text/javascript" src="/js/nav.js"></script>
</body>
</html>


