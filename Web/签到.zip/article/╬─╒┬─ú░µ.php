<?php
  
if(!isset($_GET['id']))
  die(0);
$id=$_GET['id'];
  include "./htmlport.php";
  $link=connect();
  $res=mysql_query($link,"select * from essay,content where id='$id'");
  if($row=mysql_fetch_array($res))
  {
    $title=$row['title'];
    $time=$row['time'];
    
    $con=$row['con'];
  }
  else    die();
  $author='c0d1';
?>

<!DOCTYPE HTML>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title><?php echo "$title"; ?></title>
<link rel="stylesheet" href="../css/index.css"/>
<link rel="stylesheet" href="../css/style.css"/>
<script type="text/javascript" src="../js/jquery1.42.min.js"></script>
<script type="text/javascript" src="../js/jquery.SuperSlide.2.1.1.js"></script>
<style type="text/css">
a{color:#0099CC;}
a:hover{color:#99CCFF;}
br{height: 3px;}
.news_text{
  font-size: 18px;
}
</style>
</head>
<body>
    <?php  
      headerport();#header
      navport();#start 
    ?>
    <!--content start-->
    <div id="content">
       <!--left-->
         <div class="left" id="news">
           <div class="weizi">
           <div class="wz_text">当前位置：<a href="#">首页</a>><a href="#">学无止境</a>><span>文章内容</span></div>
           </div>
           <div class="news_content">
                  <div class="news_top">
                    <h1><?php echo $title; ?></h1>
                    <p>
                      <span class="left sj">时间:<?php echo Date("y-m-d",$time) ?></span>
                      <span class="left author"><?php echo $author; ?></span>
                    </p>
                    <div class="clear"></div>
                  </div>
                    <div class="news_text">

<?php echo $con;?>


<br><br><br>            </div>
           </div>
     
         </div>
         <!--end left -->

         <!--right-->
         <div class="right" id="c_right">
          <?php 
            blogerport();#简介 
            lanmuboxport(); #栏目分类
            friendlink(); #友情链接
          ?>
         </div>
         <!--end  right-->
         <div class="clear"></div>
         
    </div>
    <!--content end-->
    <!--footer-->
    <?php footerport();?>
    <!--footer end-->
    <script type="text/javascript">jQuery(".lanmubox").slide({easing:"easeOutBounce",delayTime:400});</script>
    <script  type="text/javascript" src="js/nav.js"></script>
</body>
</html>


