<?php include './htmlport.php';?>
<?php
	$name=$_POST['name'];
	if(!strlen($name))			die("昵称不能为空哦");
	if(strlen($name)>10)		die("昵称长度不能多于10位哦");

	$qq=$_POST['qq'];
	if(!preg_match('/^[0-9]+$/u', "$qq"))		die("QQ号不符合规则！");#防止绕过js提交

	$power=$_POST['power'];
	if($power==="every") $power=1;
	elseif($power==="private") $power=0;	
	else die("可以的，不过还是不行！");

	$ip=$_POST['ip'];
	if(!preg_match('/^[0-9.]+$/u', "$ip"))		die("不要改ip好吗");

	$ipadr=$_POST['ipadr'];
	if(!preg_match('/^[\x{4e00}-\x{9fa5}]+$/u', "$ipadr"))	die("我靠，你连这个都不放过！");

	$time=time();

	$message=$_POST['message'];
	if(strlen($message)>500)	die("留言内容过长，请缩短一点吧╯﹏╰");

	$message=htmlspecialchars($message);#php中对于特殊字符的转义: & " ' < > 
	$ipadr=htmlspecialchars($ipadr);

	$_SESSION['msg'][] = array(
		'name' => $name,
		'message' => $message,
		'qq' => $qq,
		'power' => $power,
		'ip' => $ip,
		'ipadr' => $ipadr,
		'time' => $time
	);
	echo "留言成功！";

?>