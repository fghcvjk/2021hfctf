<?php

$flag = '?';
echo "ok\n";