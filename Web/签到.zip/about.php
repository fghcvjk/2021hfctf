<?php include './htmlport.php';?>
<!DOCTYPE HTML>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>关于我-个人博客</title>
<meta name="keywords" content="个人博客" />
<meta name="description" content="" />
<link rel="stylesheet" href="css/index.css"/>
<link rel="stylesheet" href="css/style.css"/>
<script type="text/javascript" src="js/jquery1.42.min.js"></script>
<script type="text/javascript" src="js/jquery.SuperSlide.2.1.1.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<![endif]-->
</head>

<body>
    <!--header start-->
      <?php  headerport();   ?>
    <!--header end-->

    <!--nav-->
      <?php navport(); ?>
    <!--nav end--> 

    <!--content start-->
    <div id="content">
       <!--left-->
         <div class="left" id="about_me">
           <div class="weizi">
           <div class="wz_text">当前位置：<a href="./index.php">首页</a>><h1>关于我</h1></div>
           </div>
           <div class="about_content">
             <center>博主是一个什么都不会的博主，喜欢研究偷懒的方法。</center>
           </div>
         </div>
         <!--end left -->



         <!--right-->
         <div class="right" id="c_right">
          <?php blogerport(); ?>
          <!--栏目分类-->
            <?php lanmuboxport(); ?>
          <!--end-->
         </div>
         <!--right end-->

         <div class="clear"></div>
         
    </div>
    <!--content end-->
    <!--footer-->
      <?php footerport();?>
    <!--footer end-->
    <script type="text/javascript">jQuery(".lanmubox").slide({easing:"easeOutBounce",delayTime:400});</script>
    <script  type="text/javascript" src="js/nav.js"></script>
</body>
</html>
