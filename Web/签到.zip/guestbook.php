<?php include './htmlport.php';?>
<!DOCTYPE HTML>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>留言板-个人博客</title>
<meta name="keywords" content="个人博客" />
<meta name="description" content="" />
<link rel="stylesheet" href="css/index.css"/>
<link rel="stylesheet" href="css/message.css" />
<link rel="stylesheet" href="css/style.css"/>
<script type="text/javascript" src="js/jquery1.42.min.js"></script>
<script type="text/javascript" src="js/jquery.SuperSlide.2.1.1.js"></script>
<script src="http://pv.sohu.com/cityjson?ie=utf-8"></script>
<script type="text/javascript" src="js/message.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<![endif]-->
</head>

<body>
    <?php  
      headerport();#header
      navport();#start 
    ?>

    <!--content start-->
    <div id="content">
       <!--left-->
         <div class="left" id="guestbook">
           <div class="weizi">
           <div class="wz_text">当前位置：<a href="./index.php">首页</a>><h1>留言板</h1></div>
           </div>
           <div class="g_content">


           <div style="width: 100%;height: 50px;background-color:rgb(236, 236, 236);margin-bottom: 10px;">
             <!-- <input id="write" onclick="write()" type="button" style="width: 50%;height: 50px;float: left;" value="write" />
             <input id="read" onclick="read()" type="button" style="width:50%;height: 49px;float: right;" value="read" /> -->

           </div>
<!-- 留言部分 -->
<div class="bootstrap-frm" id="bootstrap" style="">
    <form class="STYLE-NAME">
      <h1>Message
      <span>既然来了，总应该留点什么的</span>
      </h1>
      <label style='text-align: center;height: 40px;'>昵称 :&nbsp;
        <input id='name' type='text' name='name' placeholder='Your Name' value='匿名' required="required" maxlength="10" style="width: 15%;" title="昵称" />
        &nbsp;&nbsp;&nbsp;&nbsp;QQ :&nbsp;
        <input id='qq' type='text' name='QQ' placeholder='Your QQ' maxlength="10" required="required" title="QQ" />
        &nbsp;&nbsp;&nbsp;&nbsp;查看权限 :&nbsp;
        <select name="power" id="power">
          <option value="every">所有人可见</option>
          <option value="private">仅博主可见</option>
        </select>
      </label>

      <label>
        <textarea id="message" name="message" placeholder="Your Message to Me" required="required" title="你想说的话"></textarea>
      </label>

      <label style="padding-left: 40%;width: 90px;">
        <input type="button" id="sendbutton" class="button" value="Send" />
      </label>
    </form>
</div>
<br>
<br>
<br>
<div style="width: 100%;height: 50px;background-color:#E8E8E8;margin-bottom: 10px;text-align: center;line-height: 40px;
font-size: 20px;color:#40E0D0">
留言部分
           </div>

<div id="message" style="">
<?php
foreach ($_SESSION['msg'] as $key => $value) {
  $name=$value['name'];
  $time=$value['time'];
  $ipadr=$value['ipadr'];
  $content=$value['message'];
echo "<div style='background-color:#F5F5F5; width: 90%;height: 150px;margin-left:5%;margin-top: 10px; border-radius:15px;'>
<div style='width: 80%;margin-left: 5%; height: 15%;padding:1% 5% 0 5%'>$name&nbsp;&nbsp;".Date("m-d",$time)."&nbsp;&nbsp;$ipadr</div>
<div style='width: 80%; height: 80%; margin-left: 5%; margin-top: 1%; padding-left: 5%;word-wrap: break-word;padding-right: 5%;'>$content</div>
</div>";  
}
?>
</div>
<br>
<br>
<br>




           </div>
         </div>
         <!--end left -->

         <!--right-->
         <div class="right" id="c_right">
          <?php 
            blogerport();#简介 
            lanmuboxport(); #栏目分类
            friendlink(); #友情链接
          ?>
         </div>
         <!--right end-->
         <div class="clear"></div>
         
    </div>
    <!--content end-->
    <!--footer-->
    <?php footerport();?>
    <!--footer end-->
    <script type="text/javascript">jQuery(".lanmubox").slide({easing:"easeOutBounce",delayTime:400});</script>
    <script  type="text/javascript" src="js/nav.js"></script>
</body>
</html>

