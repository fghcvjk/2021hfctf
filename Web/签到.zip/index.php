<?php include './htmlport.php';?>
<!DOCTYPE HTML>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>个人博客</title>
<meta name="keywords" content="个人博客" />
<meta name="description" content="" />
<link rel="stylesheet" href="css/index.css"/>
<link rel="stylesheet" href="css/style.css"/>
<script type="text/javascript" src="js/jquery1.42.min.js"></script>
<script type="text/javascript" src="js/jquery.SuperSlide.2.1.1.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<![endif]-->
</head>

<body>
    <?php  
      headerport();#header
      navport();#start 
    ?>

    <!--content start-->
    <div id="content">
      <!--left-->
      <div class="left" id="c_left">
           <div class="s_tuijian">
           <h2>文章<span>推荐</span></h2>
           </div>
           <div class="content_text">
            <?php
                foreach ($articles as $key => $row)
                {
                  $href=$row['href'];
                  $title=$row['title'];
                  $img=$row['img'];
                  $time=Date("y-m-d",$row['time']);
                  $content = $row['content'];
                  echo "<div class='wz'><h3><a href='$href' title='$title'>$title</a></h3><dl><dt><img src='$img' width='200' height='123' alt=''></dt><dd><p class='dd_text_1'><a id='essay' href='$href'> $content </a></p><p class='dd_text_2'><span class='left author'>c0d1</span><span class='left sj'>时间:$time</span><div class='clear'></div></p></dd><div class='clear'></div></dl></div>\n\t\t\t<!--wz-->\n";
                }
            ?>
           </div>
      </div>
         <!--left end-->

         <!--right-->
         <div class="right" id="c_right">
          <?php 
            blogerport();#简介 
            lanmuboxport(); #栏目分类
            friendlink(); #友情链接
          ?>
         </div>
         <!--right end-->
         <div class="clear"></div>
    </div>
    <!--content end-->
    <!--footer start-->
    <?php footerport();?>
    <!--footer end-->
    <script type="text/javascript">jQuery(".lanmubox").slide({easing:"easeOutBounce",delayTime:400});</script>
    <script  type="text/javascript" src="js/nav.js"></script>
</body>
</html>
