<?php
	header("Content-type: text/html; charset=utf-8");
#设置php时区
date_default_timezone_set('Asia/Shanghai');	
session_start();
	function connect()
	{
		$link=mysqli_connect("localhost","root","","blog1");
		mysqli_set_charset($link,"utf-8");
		return $link;
	}

	function headerport()
	{
		echo "<!--header start-->
		    <div id='header'>
		    <h1>个人博客</h1>
		    <p>青春是打开了,就合不上的书。人生是踏上了，就回不了头的路，爱情是扔出了，就收不回的赌注。</p>    
		    </div>
		    <!--header end-->";
	}

	function navport()
	{
		echo "     <div id='nav'>
        <ul>
         <li><a href='/index.php'>首页</a></li>
         <li><a href='/about.php'>关于我</a></li>
         <li><a href='/shuo.php'>碎言碎语</a></li>
         <li><a href='/note.php'>个人日记</a></li>
         <li><a href='/guestbook.php'>留言板</a></li>
         <div class='clear'></div>
        </ul>
      </div>";
	}

	function  blogerport()
	{
		echo "<div class='s_about'>
          <h2>关于博主</h2>
           <img src='/images/me.jpg' width='230' height='230' alt='博主'/>
           <p>博主：code</p>
           <p>职业：student</p>
           <p>简介：无</p>
           <p>
           <!-- <a href='javascript:;' onclick='showqq()' title='联系博主'><span class='left b_1'>联系博主</span></a>
           <script>
			function showqq(){alert('23333333');}
           </script>
            -->
           <div class='clear'></div>
           </p>
           <br />
          </div>";
	}

	function lanmuboxport()
	{
		echo "<div class='lanmubox'>
              <div class='hd'>
               <ul><li>精心推荐</li><li>最新文章</li><li class='hd_3'>随机文章</li></ul></div>";
        echo "<div class='bd'>";
		echo "<ul>";#精心推荐
		echo "<li><a href='/article/1.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/2.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/3.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/4.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/5.php' title='title1'>title1</a></li>";
		echo "</ul>\n<ul>";

		echo "<li><a href='/article/1.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/2.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/3.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/4.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/5.php' title='title1'>title1</a></li>";
		echo "</ul>\n<ul>";

		echo "<li><a href='/article/1.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/2.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/3.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/4.php' title='title1'>title1</a></li>";
		echo "<li><a href='/article/5.php' title='title1'>title1</a></li>";
		echo "</ul>";
        echo "</div></div>";
	}
	
	function friendlink()#添加友链
	{
		echo "<div class='link'>
		            <h2>友情链接</h2>
		            <p><a href=\"https://blog.onlydown.com\">none</a></p>
		           </div>";
	}

	function footerport()#这里有个链接
	{
	echo "<div id='footer'>
    <p>Design by:<a href='#' target='_blank'>code</a> 2016-05-01</p>
    </div>";
	}

$articles=array(
  array('href' => '/article/1.php',
   'title' => '渗透测试工具大全', 
   'img' => '/images/s1.jpg', 
   'time' => 1459621325, 
   'author' => 'code', 
   'sort' => '工具',
   'content' => 'Firefox是一个出自Mozilla组织的流行的web浏览器。Firefox的流行并不仅仅是因为它是一个好的浏览器，而是因为它能够支持插件进而加强它自身的功能......',
  ),
  array('href' => '/article/2.php', 
  	'title' => 'chrome查看密码', 
  	'img' => '/images/s2.jpg', 
  	'time' => 1462257683, 
  	'author' => 'code', 
  	'sort' => '教程',
    'content' => '同事或朋友外出有事，电脑未锁屏离开座位。可以利用这一间隙，查看Ta在Chrome浏览器上保存的账号密码......',
  ),
  array('href' => '/article/3.php', 
  	'title' => 'http协议', 
  	'img' => '/images/s3.jpg', 
  	'time' => 1462437682, 
  	'author' => 'code', 
  	'sort' => '资料',
    'content' => 'HTTP协议的主要特点可概括如下......',
  ),
  array('href' => '/article/4.php', 
  	'title' => '学会使用 dll ', 
  	'img' => '/images/s0.jpg', 
  	'time' => 1462837682, 
  	'author' => 'code', 
  	'sort' => '资料',
    'content' => '我们需要学会使用 dll 是为了模块化编程,这点非常好,而编译调用 dll 我们需要解决如下的问题......',
  ),
  array('href' => '/article/5.php', 
    'title' => '【新手必备！！！】手把手教学源码级博客搭建过程', 
    'img' => '/images/s0.jpg', 
    'time' => 1617387725, 
    'author' => 'code', 
    'sort' => '教程',
    'content' => '本文为零基础 Z2blog 建站教程，手把手教你从零开始搭建 Z2blog 个人博客。......',
  ),
);
?>