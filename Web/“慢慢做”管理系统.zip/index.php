<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<body>
<form action="" method="get">
username：<input type="text" name="username" value=""><br />
password：<input type="text" name="password" value=""><br />
<input type="submit" value="Submit">
</form>
</body>
<!-- 题目描述还是比较重要的。 -->
</html>


