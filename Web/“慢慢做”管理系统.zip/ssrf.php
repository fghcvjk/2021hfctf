<!DOCTYPE html>
<html>
<body>

<form action="">
your way to gopher<br>
<input type="text" name="way" value="">
<br>
<input type="submit" value="Submit">
</form>

</body>
</html>



